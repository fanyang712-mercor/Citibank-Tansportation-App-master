package Modules;

/**
 * Created by yianmo on 10/13/17.
 */
public class Duration {
    public String text;
    public int value;

    public Duration(String text, int value) {
        this.text = text;
        this.value = value;
    }
}
